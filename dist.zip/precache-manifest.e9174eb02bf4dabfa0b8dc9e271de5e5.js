self.__precacheManifest = [
  {
    "revision": "e76a3e138af844b76e86",
    "url": "assets/global/css/components.css"
  },
  {
    "revision": "0dcb68f330a027eb1ec3c32437ee5508",
    "url": "img/fire.gif"
  },
  {
    "revision": "1ec0428bddeb839c0204406484ececae",
    "url": "img/logo@1x.png"
  },
  {
    "revision": "90e3ae396a8f846c9739f756382d406f",
    "url": "img/logo.png"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "revision": "5e606bf9e8f5fce5b9666e6336d126a6",
    "url": "index.html"
  },
  {
    "revision": "485fc432e3a718c58d43",
    "url": "assets/global/css/music.css"
  },
  {
    "revision": "f352b44f46674f4db1c2",
    "url": "assets/global/js/article.js"
  },
  {
    "revision": "485fc432e3a718c58d43",
    "url": "assets/global/js/music.js"
  },
  {
    "revision": "a9caa123ccbcbfd74fad",
    "url": "assets/global/js/chunk-vendors.js"
  },
  {
    "revision": "c6637a52b0b8a2f71cde",
    "url": "assets/global/js/example.js"
  },
  {
    "revision": "e76a3e138af844b76e86",
    "url": "assets/global/js/components.js"
  },
  {
    "revision": "87c6dd912d5a1466dde4",
    "url": "assets/global/js/article-details.js"
  },
  {
    "revision": "6409cdbe276de480c2b1",
    "url": "assets/global/js/app.js"
  },
  {
    "revision": "177b7c9fba0b133bf25a",
    "url": "assets/global/js/about.js"
  },
  {
    "revision": "b6f063c06266b785c644",
    "url": "assets/global/js/404.js"
  },
  {
    "revision": "f352b44f46674f4db1c2",
    "url": "assets/global/css/article.css"
  },
  {
    "revision": "87c6dd912d5a1466dde4",
    "url": "assets/global/css/article-details.css"
  },
  {
    "revision": "6409cdbe276de480c2b1",
    "url": "assets/global/css/app.css"
  },
  {
    "revision": "b6f063c06266b785c644",
    "url": "assets/global/css/404.css"
  },
  {
    "revision": "a287f35a46a1641f50a6ab5cc532d1a0",
    "url": "README.md"
  }
];